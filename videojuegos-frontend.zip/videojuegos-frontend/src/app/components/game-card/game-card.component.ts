import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './game-card.component.html',
  styleUrl: './game-card.component.scss'
})
export class GameCardComponent {
  @Input() juego: any;

  constructor(private router: Router) {}

  verDetalle(): void {
    this.router.navigate(['/juego', this.juego.id]);
  }

  getBadgeClass(categoria: string): string {
    const map: any = {
      'RPG': 'badge-purple',
      'Acción': 'badge-blue',
      'Shooter': 'badge-blue',
      'Deportes': 'badge-cyan',
      'Sandbox': 'badge-cyan',
      'Simulación': 'badge-cyan',
      'Indie': 'badge-purple',
      'Survival Horror': 'badge-blue',
    };
    return map[categoria] || 'badge-blue';
  }
}