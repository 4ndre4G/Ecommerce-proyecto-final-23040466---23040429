import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ComprasService } from '../../services/compras.service';

@Component({
  selector: 'app-mis-compras',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './mis-compras.component.html',
  styleUrl: './mis-compras.component.scss'
})
export class MisComprasComponent implements OnInit {
  compras: any[] = [];
  total_gastado = '0.00';
  loading = true;
  error = '';

  constructor(
    private comprasService: ComprasService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.comprasService.getMisCompras().subscribe({
      next: (res: any) => {
        this.compras = res.compras;
        this.total_gastado = res.total_gastado;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.error = 'Error al cargar tu historial.';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }
}