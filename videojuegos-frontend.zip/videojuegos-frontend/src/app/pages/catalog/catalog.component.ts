import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VideojuegosService } from '../../services/videojuegos.service';
import { GameCardComponent } from '../../components/game-card/game-card.component';

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule, FormsModule, GameCardComponent],
  templateUrl: './catalog.component.html',
  styleUrl: './catalog.component.scss'
})
export class CatalogComponent implements OnInit {
  juegos: any[] = [];
  juegosFiltrados: any[] = [];
  loading = true;
  error = '';

  search = '';
  categoriaSeleccionada = '';

  categorias = ['RPG', 'Acción', 'Shooter', 'Deportes', 'Sandbox', 'Simulación', 'Indie', 'Survival Horror'];

  constructor(
    private videojuegosService: VideojuegosService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.cargarJuegos();
  }

  cargarJuegos(): void {
    this.loading = true;
    this.videojuegosService.getAll().subscribe({
      next: (data) => {
        this.juegos = data;
        this.juegosFiltrados = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.error = 'Error al cargar el catálogo.';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  filtrar(): void {
    this.juegosFiltrados = this.juegos.filter(j => {
      const matchSearch    = !this.search || j.titulo.toLowerCase().includes(this.search.toLowerCase());
      const matchCategoria = !this.categoriaSeleccionada || j.categoria === this.categoriaSeleccionada;
      return matchSearch && matchCategoria;
    });
    this.cdr.detectChanges();
  }

  limpiarFiltros(): void {
    this.search = '';
    this.categoriaSeleccionada = '';
    this.juegosFiltrados = this.juegos;
    this.cdr.detectChanges();
  }
}