import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { CarritoService } from '../../services/carrito.service';
import { ComprasService } from '../../services/compras.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-carrito',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './carrito.component.html',
  styleUrl: './carrito.component.scss'
})
export class CarritoComponent {
  comprando = false;
  error = '';
  success = '';

  constructor(
    public carritoService: CarritoService,
    private comprasService: ComprasService,
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  eliminar(id: number): void {
    this.carritoService.eliminar(id);
    this.cdr.detectChanges();
  }

  confirmarCompra(): void {
    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }
    this.comprando = true;
    this.error = '';
    const items = this.carritoService.getItems();
    const promesas = items.map(item =>
      this.comprasService.comprar(item.id, 1).toPromise()
    );
    Promise.all(promesas)
      .then(() => {
        this.success = `¡Compra exitosa! Adquiriste ${items.length} juego(s).`;
        this.carritoService.vaciar();
        this.comprando = false;
        this.cdr.detectChanges();
        setTimeout(() => this.router.navigate(['/mis-compras']), 2000);
      })
      .catch((err) => {
        this.error = err?.error?.message || 'Error al procesar la compra.';
        this.comprando = false;
        this.cdr.detectChanges();
      });
  }
}