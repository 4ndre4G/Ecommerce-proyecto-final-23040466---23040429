import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { VideojuegosService } from '../../services/videojuegos.service';
import { CarritoService } from '../../services/carrito.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-detalle-juego',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detalle-juego.component.html',
  styleUrl: './detalle-juego.component.scss'
})
export class DetalleJuegoComponent implements OnInit {
  juego: any = null;
  loading = true;
  error = '';
  mensajeCarrito = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private videojuegosService: VideojuegosService,
    public carritoService: CarritoService,
    public auth: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.videojuegosService.getById(id).subscribe({
      next: (data) => {
        this.juego = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.error = 'Juego no encontrado.';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  agregarAlCarrito(): void {
    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }
    this.carritoService.agregar({
      id:        this.juego.id,
      titulo:    this.juego.titulo,
      precio:    parseFloat(this.juego.precio),
      imagen_url: this.juego.imagen_url,
      categoria: this.juego.categoria,
    });
    this.mensajeCarrito = '¡Agregado al carrito!';
    this.cdr.detectChanges();
    setTimeout(() => { this.mensajeCarrito = ''; this.cdr.detectChanges(); }, 2500);
  }

  irAlCarrito(): void {
    this.router.navigate(['/carrito']);
  }

  volver(): void {
    this.router.navigate(['/catalog']);
  }
}