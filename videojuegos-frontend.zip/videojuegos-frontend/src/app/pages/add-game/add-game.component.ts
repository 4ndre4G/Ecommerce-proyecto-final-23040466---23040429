import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { VideojuegosService } from '../../services/videojuegos.service';

@Component({
  selector: 'app-add-game',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-game.component.html',
  styleUrl: './add-game.component.scss'
})
export class AddGameComponent {
  form: any = {
    titulo: '', descripcion: '', categoria: '',
    requisitos_hardware: '', precio: null,
    stock: null, imagen_url: '', fecha_lanzamiento: ''
  };
  loading = false;
  error = '';
  success = '';

  categorias = ['RPG', 'Acción', 'Shooter', 'Deportes', 'Sandbox', 'Simulación', 'Indie', 'Survival Horror'];

  constructor(private videojuegosService: VideojuegosService, private router: Router) {}

  onSubmit(): void {
    if (!this.form.titulo || !this.form.precio) {
      this.error = 'Título y precio son obligatorios.';
      return;
    }
    this.loading = true;
    this.error = '';
    this.success = '';
    this.videojuegosService.create(this.form).subscribe({
      next: () => {
        this.success = '¡Juego agregado exitosamente!';
        this.loading = false;
        setTimeout(() => this.router.navigate(['/catalog']), 1500);
      },
      error: (err) => {
        this.error = err.error?.message || 'Error al agregar el juego.';
        this.loading = false;
      }
    });
  }

  cancelar(): void {
    this.router.navigate(['/catalog']);
  }
}