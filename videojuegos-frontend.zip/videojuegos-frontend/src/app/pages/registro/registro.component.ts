import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.scss'
})
export class RegistroComponent {
  form = { nombre_usuario: '', email: '', password: '', edad: null };
  error = '';
  loading = false;

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    if (!this.form.nombre_usuario || !this.form.email || !this.form.password) {
      this.error = 'Nombre, email y contraseña son obligatorios.';
      return;
    }
    if (this.form.password.length < 6) {
      this.error = 'La contraseña debe tener al menos 6 caracteres.';
      return;
    }
    this.loading = true;
    this.error = '';
    this.auth.registro(this.form).subscribe({
      next: () => this.router.navigate(['/catalog']),
      error: (err) => {
        this.error = err.error?.message || 'Error al registrarse.';
        this.loading = false;
      }
    });
  }
}