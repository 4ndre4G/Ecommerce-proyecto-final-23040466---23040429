import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { adminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'catalog', pathMatch: 'full' },
  {
    path: 'catalog',
    loadComponent: () => import('./pages/catalog/catalog.component').then(m => m.CatalogComponent)
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'registro',
    loadComponent: () => import('./pages/registro/registro.component').then(m => m.RegistroComponent)
  },
  {
    path: 'juego/:id',
    loadComponent: () => import('./pages/detalle-juego/detalle-juego.component').then(m => m.DetalleJuegoComponent)
  },
  {
    path: 'carrito',
    loadComponent: () => import('./pages/carrito/carrito.component').then(m => m.CarritoComponent)
  },
  {
    path: 'mis-compras',
    loadComponent: () => import('./pages/mis-compras/mis-compras.component').then(m => m.MisComprasComponent),
    canActivate: [authGuard]
  },
  {
    path: 'add-game',
    loadComponent: () => import('./pages/add-game/add-game.component').then(m => m.AddGameComponent),
    canActivate: [authGuard, adminGuard]
  },
  { path: '**', redirectTo: 'catalog' }
];