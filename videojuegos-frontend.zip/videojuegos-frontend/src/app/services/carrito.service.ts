import { Injectable, signal, computed } from '@angular/core';

export interface ItemCarrito {
  id: number;
  titulo: string;
  precio: number;
  imagen_url: string;
  categoria: string;
}

@Injectable({ providedIn: 'root' })
export class CarritoService {
  private items = signal<ItemCarrito[]>([]);

  // Signals computados
  total     = computed(() => this.items().reduce((acc, i) => acc + i.precio, 0));
  cantidad  = computed(() => this.items().length);
  getItems  = computed(() => this.items());

  agregar(juego: ItemCarrito): void {
    const yaExiste = this.items().some(i => i.id === juego.id);
    if (yaExiste) return; // un juego = una unidad
    this.items.update(items => [...items, juego]);
  }

  eliminar(id: number): void {
    this.items.update(items => items.filter(i => i.id !== id));
  }

  estaEnCarrito(id: number): boolean {
    return this.items().some(i => i.id === id);
  }

  vaciar(): void {
    this.items.set([]);
  }
}