import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = environment.apiUrl;
  private usuarioSubject = new BehaviorSubject<any>(this.getUsuarioLocal());
  usuario$ = this.usuarioSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  registro(datos: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/registro`, datos).pipe(
      tap((res: any) => this.guardarSesion(res))
    );
  }

  login(datos: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/login`, datos).pipe(
      tap((res: any) => this.guardarSesion(res))
    );
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    this.usuarioSubject.next(null);
    this.router.navigate(['/login']);
  }

  private guardarSesion(res: any): void {
    localStorage.setItem('token', res.token);
    localStorage.setItem('usuario', JSON.stringify(res.usuario));
    this.usuarioSubject.next(res.usuario);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUsuarioLocal(): any {
    const u = localStorage.getItem('usuario');
    return u ? JSON.parse(u) : null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    const u = this.getUsuarioLocal();
    return u?.rol === 'admin';
  }
}