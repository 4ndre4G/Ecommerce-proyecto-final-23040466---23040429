import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class ComprasService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient, private auth: AuthService) {}

  private headers(): HttpHeaders {
    return new HttpHeaders({ Authorization: `Bearer ${this.auth.getToken()}` });
  }

  comprar(videojuego_id: number, cantidad: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/compras`, { videojuego_id, cantidad }, { headers: this.headers() });
  }

  getMisCompras(): Observable<any> {
    return this.http.get(`${this.apiUrl}/compras/mis-compras`, { headers: this.headers() });
  }
}