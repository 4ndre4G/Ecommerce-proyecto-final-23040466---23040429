import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class VideojuegosService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient, private auth: AuthService) {}

  private headers(): HttpHeaders {
    return new HttpHeaders({ Authorization: `Bearer ${this.auth.getToken()}` });
  }

  getAll(filtros?: { categoria?: string; plataforma?: string; search?: string }): Observable<any[]> {
    let params = new HttpParams();
    if (filtros?.categoria)  params = params.set('categoria', filtros.categoria);
    if (filtros?.plataforma) params = params.set('plataforma', filtros.plataforma);
    if (filtros?.search)     params = params.set('search', filtros.search);
    return this.http.get<any[]>(`${this.apiUrl}/videojuegos`, { params });
  }

  getById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/videojuegos/${id}`);
  }

  create(juego: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/videojuegos`, juego, { headers: this.headers() });
  }

  update(id: number, juego: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/videojuegos/${id}`, juego, { headers: this.headers() });
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/videojuegos/${id}`, { headers: this.headers() });
  }
}