require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const db      = require('./config/db');

const authRoutes        = require('./routes/auth.routes');
const videojuegosRoutes = require('./routes/videojuegos.routes');
const comprasRoutes     = require('./routes/compras.routes');
const usuarioRoutes     = require('./routes/usuario.routes');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middlewares globales ──────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ── Rutas ─────────────────────────────────────────────────────────────────────
app.use('/api/auth',        authRoutes);
app.use('/api/videojuegos', videojuegosRoutes);
app.use('/api/compras',     comprasRoutes);
app.use('/api/usuario',     usuarioRoutes);

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// ── Ruta no encontrada ────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ message: `Ruta ${req.method} ${req.url} no encontrada.` });
});

// ── Arrancar servidor con verificación de BD ─────────────────────────────────
const startServer = async () => {
  try {
    await db.raw('SELECT 1');
    console.log('✅ Conexión a PostgreSQL exitosa.');

    app.listen(PORT, () => {
      console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
      console.log(`📋 Endpoints disponibles:`);
      console.log(`   POST  /api/auth/registro`);
      console.log(`   POST  /api/auth/login`);
      console.log(`   GET   /api/videojuegos`);
      console.log(`   GET   /api/videojuegos/:id`);
      console.log(`   POST  /api/videojuegos       (admin)`);
      console.log(`   PUT   /api/videojuegos/:id   (admin)`);
      console.log(`   DELETE /api/videojuegos/:id  (admin)`);
      console.log(`   POST  /api/compras`);
      console.log(`   GET   /api/compras/mis-compras`);
      console.log(`   GET   /api/compras            (admin)`);
      console.log(`   GET   /api/usuario/perfil`);
    });

  } catch (error) {
    console.error('❌ Error al conectar con PostgreSQL:', error.message);
    console.error('   Verifica los valores en tu archivo .env');
    process.exit(1);
  }
};

startServer();
