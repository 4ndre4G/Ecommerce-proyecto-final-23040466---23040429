const db = require('../config/db');

// GET /api/usuario/perfil — datos del usuario autenticado
const getPerfil = async (req, res) => {
  const id = req.user.id;

  try {
    const usuario = await db('usuarios')
      .where({ id })
      .select('id', 'nombre_usuario', 'email', 'edad', 'rol', 'fecha_registro')
      .first();

    if (!usuario) {
      return res.status(404).json({ message: 'Usuario no encontrado.' });
    }

    return res.status(200).json(usuario);

  } catch (error) {
    console.error('Error al obtener perfil:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

module.exports = { getPerfil };
