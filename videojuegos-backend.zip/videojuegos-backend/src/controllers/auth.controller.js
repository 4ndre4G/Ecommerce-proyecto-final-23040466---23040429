const bcrypt = require('bcrypt');
const jwt    = require('jsonwebtoken');
const db     = require('../config/db');

// POST /api/auth/registro
const registro = async (req, res) => {
  const { nombre_usuario, email, password, edad } = req.body;

  if (!nombre_usuario || !email || !password) {
    return res.status(400).json({ message: 'nombre_usuario, email y password son obligatorios.' });
  }

  try {
    // Verificar si el email o nombre ya existen
    const existente = await db('usuarios')
      .where({ email })
      .orWhere({ nombre_usuario })
      .first();

    if (existente) {
      return res.status(409).json({ message: 'El email o nombre de usuario ya está registrado.' });
    }

    const hash = await bcrypt.hash(password, 10);

    const [nuevoUsuario] = await db('usuarios')
      .insert({
        nombre_usuario,
        email,
        password: hash,
        edad: edad || null,
        rol: 'cliente',
      })
      .returning(['id', 'nombre_usuario', 'email', 'edad', 'rol', 'fecha_registro']);

    const token = jwt.sign(
      { id: nuevoUsuario.id, nombre_usuario: nuevoUsuario.nombre_usuario, email: nuevoUsuario.email, rol: nuevoUsuario.rol },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    return res.status(201).json({
      message: 'Usuario registrado exitosamente.',
      token,
      usuario: nuevoUsuario,
    });

  } catch (error) {
    console.error('Error en registro:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email y password son obligatorios.' });
  }

  try {
    const usuario = await db('usuarios').where({ email }).first();

    if (!usuario) {
      return res.status(401).json({ message: 'Credenciales incorrectas.' });
    }

    const passwordValida = await bcrypt.compare(password, usuario.password);

    if (!passwordValida) {
      return res.status(401).json({ message: 'Credenciales incorrectas.' });
    }

    const token = jwt.sign(
      { id: usuario.id, nombre_usuario: usuario.nombre_usuario, email: usuario.email, rol: usuario.rol },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    return res.status(200).json({
      message: 'Login exitoso.',
      token,
      usuario: {
        id:             usuario.id,
        nombre_usuario: usuario.nombre_usuario,
        email:          usuario.email,
        rol:            usuario.rol,
      },
    });

  } catch (error) {
    console.error('Error en login:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

module.exports = { registro, login };
