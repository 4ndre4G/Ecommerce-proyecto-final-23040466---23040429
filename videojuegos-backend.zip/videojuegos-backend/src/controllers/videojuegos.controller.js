const db = require('../config/db');

// GET /api/videojuegos — catálogo completo (con filtros opcionales)
const getAll = async (req, res) => {
  const { categoria, plataforma, search } = req.query;

  try {
    let query = db('videojuegos').select('*').orderBy('titulo', 'asc');

    if (categoria)  query = query.where({ categoria });
    if (plataforma) query = query.where({ plataforma });
    if (search)     query = query.whereILike('titulo', `%${search}%`);

    const videojuegos = await query;
    return res.status(200).json(videojuegos);

  } catch (error) {
    console.error('Error al obtener videojuegos:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// GET /api/videojuegos/:id — detalle de un juego
const getById = async (req, res) => {
  const { id } = req.params;

  try {
    const juego = await db('videojuegos').where({ id }).first();

    if (!juego) {
      return res.status(404).json({ message: 'Videojuego no encontrado.' });
    }

    return res.status(200).json(juego);

  } catch (error) {
    console.error('Error al obtener videojuego:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// POST /api/videojuegos — crear (solo admin)
const create = async (req, res) => {
  const { titulo, descripcion, categoria, plataforma, requisitos_hardware, precio, stock, imagen_url, fecha_lanzamiento } = req.body;

  if (!titulo || precio === undefined || precio === null) {
    return res.status(400).json({ message: 'titulo y precio son obligatorios.' });
  }

  try {
    const existente = await db('videojuegos').where({ titulo }).first();

    if (existente) {
      return res.status(409).json({ message: 'Ya existe un videojuego con ese título.' });
    }

    const [nuevoJuego] = await db('videojuegos')
      .insert({ titulo, descripcion, categoria, plataforma, requisitos_hardware, precio, stock: stock || 0, imagen_url, fecha_lanzamiento })
      .returning('*');

    return res.status(201).json({ message: 'Videojuego creado exitosamente.', juego: nuevoJuego });

  } catch (error) {
    console.error('Error al crear videojuego:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// PUT /api/videojuegos/:id — actualizar (solo admin)
const update = async (req, res) => {
  const { id } = req.params;
  const campos = req.body;

  // No permitir cambiar el id
  delete campos.id;

  try {
    const juego = await db('videojuegos').where({ id }).first();

    if (!juego) {
      return res.status(404).json({ message: 'Videojuego no encontrado.' });
    }

    const [actualizado] = await db('videojuegos')
      .where({ id })
      .update(campos)
      .returning('*');

    return res.status(200).json({ message: 'Videojuego actualizado.', juego: actualizado });

  } catch (error) {
    console.error('Error al actualizar videojuego:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// DELETE /api/videojuegos/:id — eliminar (solo admin)
const remove = async (req, res) => {
  const { id } = req.params;

  try {
    const juego = await db('videojuegos').where({ id }).first();

    if (!juego) {
      return res.status(404).json({ message: 'Videojuego no encontrado.' });
    }

    // Verificar si tiene compras asociadas (ON DELETE RESTRICT)
    const comprasAsociadas = await db('compras').where({ videojuego_id: id }).count('id as total').first();

    if (parseInt(comprasAsociadas.total) > 0) {
      return res.status(409).json({ message: 'No se puede eliminar: el juego tiene compras registradas.' });
    }

    await db('videojuegos').where({ id }).del();

    return res.status(200).json({ message: 'Videojuego eliminado exitosamente.' });

  } catch (error) {
    console.error('Error al eliminar videojuego:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

module.exports = { getAll, getById, create, update, remove };
