const db = require('../config/db');

// POST /api/compras — realizar una compra
const comprar = async (req, res) => {
  const { videojuego_id, cantidad } = req.body;
  const usuario_id = req.user.id; // viene del token JWT

  if (!videojuego_id || !cantidad || cantidad < 1) {
    return res.status(400).json({ message: 'videojuego_id y cantidad (>0) son obligatorios.' });
  }

  try {
    // 1. Verificar que el juego existe y tiene stock
    const juego = await db('videojuegos').where({ id: videojuego_id }).first();

    if (!juego) {
      return res.status(404).json({ message: 'Videojuego no encontrado.' });
    }

    if (juego.stock < cantidad) {
      return res.status(400).json({
        message: `Stock insuficiente. Disponible: ${juego.stock} unidad(es).`,
      });
    }

    // 2. Registrar la compra y descontar stock en una transacción
    const [nuevaCompra] = await db.transaction(async (trx) => {
      // Descontar stock
      await trx('videojuegos')
        .where({ id: videojuego_id })
        .decrement('stock', cantidad);

      // Registrar compra con el precio actual (histórico)
      return trx('compras')
        .insert({
          usuario_id,
          videojuego_id,
          cantidad,
          precio_unitario: juego.precio,
          estado: 'completada',
        })
        .returning('*');
    });

    return res.status(201).json({
      message: 'Compra realizada exitosamente.',
      compra: {
        ...nuevaCompra,
        titulo:    juego.titulo,
        subtotal:  (nuevaCompra.precio_unitario * nuevaCompra.cantidad).toFixed(2),
      },
    });

  } catch (error) {
    console.error('Error al realizar compra:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// GET /api/compras/mis-compras — historial del usuario autenticado
const getMisCompras = async (req, res) => {
  const usuario_id = req.user.id;

  try {
    const compras = await db('compras as c')
      .join('videojuegos as v', 'c.videojuego_id', 'v.id')
      .where('c.usuario_id', usuario_id)
      .select(
        'c.id',
        'c.cantidad',
        'c.precio_unitario',
        'c.estado',
        'c.fecha_compra',
        'v.titulo',
        'v.imagen_url',
        'v.categoria',
        db.raw('(c.precio_unitario * c.cantidad) as subtotal')
      )
      .orderBy('c.fecha_compra', 'desc');

    // Calcular total gastado
    const total_gastado = compras
      .reduce((acc, c) => acc + parseFloat(c.subtotal), 0)
      .toFixed(2);

    return res.status(200).json({ compras, total_gastado });

  } catch (error) {
    console.error('Error al obtener compras:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// GET /api/compras — todas las compras (solo admin)
const getAll = async (req, res) => {
  try {
    const compras = await db('compras as c')
      .join('usuarios as u', 'c.usuario_id', 'u.id')
      .join('videojuegos as v', 'c.videojuego_id', 'v.id')
      .select(
        'c.id',
        'c.cantidad',
        'c.precio_unitario',
        'c.estado',
        'c.fecha_compra',
        'u.nombre_usuario',
        'u.email',
        'v.titulo',
        db.raw('(c.precio_unitario * c.cantidad) as subtotal')
      )
      .orderBy('c.fecha_compra', 'desc');

    return res.status(200).json(compras);

  } catch (error) {
    console.error('Error al obtener todas las compras:', error.message);
    return res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

module.exports = { comprar, getMisCompras, getAll };
