// Debe usarse DESPUÉS de verifyToken
const verifyAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ message: 'No autenticado.' });
  }

  if (req.user.rol !== 'admin') {
    return res.status(403).json({ message: 'Acceso restringido. Se requiere rol de administrador.' });
  }

  next();
};

module.exports = verifyAdmin;
