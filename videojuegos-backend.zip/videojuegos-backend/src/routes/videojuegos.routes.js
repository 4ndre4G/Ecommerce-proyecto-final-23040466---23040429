const express      = require('express');
const router       = express.Router();
const ctrl         = require('../controllers/videojuegos.controller');
const verifyToken  = require('../middlewares/auth.middleware');
const verifyAdmin  = require('../middlewares/admin.middleware');

// Públicas
router.get('/',    ctrl.getAll);
router.get('/:id', ctrl.getById);

// Solo admin
router.post('/',    verifyToken, verifyAdmin, ctrl.create);
router.put('/:id',  verifyToken, verifyAdmin, ctrl.update);
router.delete('/:id', verifyToken, verifyAdmin, ctrl.remove);

module.exports = router;
