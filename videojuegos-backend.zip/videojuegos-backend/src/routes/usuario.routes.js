const express     = require('express');
const router      = express.Router();
const { getPerfil } = require('../controllers/usuario.controller');
const verifyToken = require('../middlewares/auth.middleware');

// GET /api/usuario/perfil
router.get('/perfil', verifyToken, getPerfil);

module.exports = router;
