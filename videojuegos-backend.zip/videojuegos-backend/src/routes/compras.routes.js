const express     = require('express');
const router      = express.Router();
const ctrl        = require('../controllers/compras.controller');
const verifyToken = require('../middlewares/auth.middleware');
const verifyAdmin = require('../middlewares/admin.middleware');

// Usuario autenticado
router.post('/',           verifyToken, ctrl.comprar);
router.get('/mis-compras', verifyToken, ctrl.getMisCompras);

// Solo admin — ver todas las compras
router.get('/', verifyToken, verifyAdmin, ctrl.getAll);

module.exports = router;
